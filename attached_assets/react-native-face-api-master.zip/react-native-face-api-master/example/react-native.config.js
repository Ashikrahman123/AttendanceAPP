module.exports = {
    dependencies: {
        ...{ 'react-native-flipper': { platforms: { ios: null } } }
    }
}